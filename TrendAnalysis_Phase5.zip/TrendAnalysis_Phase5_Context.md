# TrendAnalysis — Phase 5 Context / Hydration

## Status

Phase 5 — Prediction Engine — implemented and synthetic validation passed.

Phase 4 remains the source of historical relationship evidence. Phase 5 adds
three-class outcome classification, method-specific prediction objects, and a
final evidence-adaptive prediction surface.

Phase 5 has not yet been validated against the live user's OLAP database.
That real-data validation should happen in the user's actual TrendAnalysis
repository after the package is merged.

---

## 1. Purpose

Phase 5 answers:

> Given the current Phase 3 state and the historically learned Phase 4
> relationships, what empirical UP / SIDEWAYS / DOWN distribution does the
> current condition imply, and is there enough evidence for a directional
> prediction?

Final output surface:

```text
Trend: UP / SIDEWAYS / DOWN / NO_CLEAR_TREND
Conviction: STRONG / MODERATE / LOW / NONE
Probabilities: UP / SIDEWAYS / DOWN
Expected return: optional empirical estimate
Data/evidence limitations
```

Phase 5 probabilities are empirical and pre-calibration. They are not yet
claiming calibrated statistical probabilities.

---

## 2. Inputs

Phase 5 consumes:

```text
current Phase 3 categorical states
+
Phase 4 HistoricalRelationshipObservation history
```

The prediction layer does not query raw DuckDB tables and does not build a
second feature pipeline.

Required historical observations are filtered to:

```text
observation.target == target
observation.as_of_date < prediction_date
```

Therefore the outcome distribution and relationship discovery for a prediction
never use the held-out/current date or future observations.

Optional audit metadata is carried through the prediction object:

- analysis_timeframe
- holding_period_months
- benchmark
- entry_mode

These are descriptive metadata and do not alter the historical evidence.

---

## 3. Phase 5.1 — Outcome Classification

File:

```text
analysis/outcome_labels.py
```

Phase 4 deliberately preserved raw future returns and did not assign
UP/SIDEWAYS/DOWN labels.

Phase 5 learns the class boundaries from the historical forward-return
distribution for the selected holding period.

Current method:

```text
lower threshold = 1/3 empirical quantile
upper threshold = 2/3 empirical quantile
```

So the thresholds are return-distribution-derived rather than hard-coded
percentages.

Classification:

```text
return < lower threshold  -> DOWN
lower <= return <= upper  -> SIDEWAYS
return > upper threshold  -> UP
```

The engine marks the analysis LIMITED when:

- the training distribution is too small, or
- lower and upper empirical boundaries collapse.

It does not fabricate a class boundary.

---

## 4. Phase 5.2 — Method-specific Prediction

File:

```text
analysis/prediction.py
```

Method A and Method B remain distinct.

### Method A

Uses the exact comparable observations selected by the Phase 4 adaptive
similarity algorithm.

The Phase 4 `RelationshipResult` now retains, internally:

```text
supporting_observations
supporting_weights
```

For Method A, selected comparable observations are retained with equal
probability weight. This avoids reimplementing the Phase 4 nearest-neighbour
logic in Phase 5.

### Method B

Uses the exact full historical distribution and adaptive observation weights
created by Phase 4 Method B.

This allows Phase 5 to construct a weighted UP / SIDEWAYS / DOWN distribution
without replacing Method B with a simpler conditional subset.

---

## 5. Baseline Distribution

The historical training return distribution is itself classified using the
same learned thresholds.

This produces:

```text
baseline UP probability
baseline SIDEWAYS probability
baseline DOWN probability
```

A directional prediction is only considered meaningful when its class share
beats its own historical baseline share.

This prevents the prediction from interpreting a common historical outcome as
special evidence merely because it is currently the largest category.

---

## 6. Direction Rule

The engine does not force a direction.

A directional class must:

1. be UP or DOWN;
2. beat its own historical baseline share; and
3. have a probability margin over the other classes that is larger than an
   adaptive sampling-uncertainty estimate.

Otherwise the result becomes either:

```text
SIDEWAYS
```

or:

```text
NO_CLEAR_TREND
```

`NO_CLEAR_TREND` is intentionally different from `SIDEWAYS`:

```text
SIDEWAYS
    = the empirical distribution itself favors the neutral class.

NO_CLEAR_TREND
    = evidence is insufficient or conflicting for a defensible direction.
```

---

## 7. Method Combination

There is no permanent 50/50 Method A/B weight.

When both methods are usable, the current probability mixture uses an
analysis-time evidence weight based on:

```text
current empirical relationship score
× relationship reliability
× effective support size
```

The weight is recalculated for each prediction.

When one method is unavailable, the other remains usable.

When Method A and Method B give conflicting directional signals, the final
trend is explicitly:

```text
NO_CLEAR_TREND
```

rather than arbitrarily choosing one method.

The probability distribution is still retained so Phase 6 can calibrate and
study the disagreement.

---

## 8. Conviction

Current evidence-state logic:

```text
STRONG
    both methods agree directionally and both are stable.

MODERATE
    both agree but one/both are not strongly stable, or a single method gives
    a usable direction without an opposing method.

LOW
    evidence is neutral, weak, or otherwise not strong enough for higher
    conviction.

NONE
    there is no defensible directional prediction, including direct method
    conflict.
```

These are evidence-state labels, not fixed market-return thresholds.

---

## 9. Phase 4 Compatibility Extension

`analysis/relationship.py` was extended without changing Method A/B discovery
logic.

The only functional addition is retention of the exact raw support used by
each returned relationship result so Phase 5 can transform that support into
class probabilities.

The public output serializer reports support counts rather than embedding all
raw observations, preventing unnecessary result-size growth.

---

## 10. Validation

Phase 5 synthetic test:

```text
PHASE 5 PREDICTION ENGINE TEST: PASS
Trend: UP
Conviction: MODERATE
Probabilities: UP 59.68 / SIDEWAYS 20.16 / DOWN 20.16
Method A: UP
Method B: UP
```

The same test also verifies that conflicting Method A/B directional signals
produce:

```text
NO_CLEAR_TREND
Conviction: NONE
```

Phase 4 regression after the Phase 5 extension:

```text
Phase 4 relationship discovery       PASS
Phase 4.2 historical panel            PASS
Phase 4.3 Method A                   PASS
Phase 4.4 Method B                   PASS
Phase 4.5 evidence ranking           PASS
Phase 4.6 combination discovery      PASS
Phase 4.7 higher-order stopping      PASS
Phase 4.8 walk-forward validation    PASS
```

The previously completed Phase 4.9 real-OLAP test remains valid:

```text
Panel rows: 59
Walk-forward folds: 47
Method A hit rate: 38.64
Method B hit rate: 52.78
Combined hit rate: 43.18
Leakage violations: 0
State future violations: 0
Outcome temporal violations: 0
```

Those Phase 4.9 numbers remain relationship-validation evidence, not Phase 5
probability-calibration results.

---

## 11. Files

```text
analysis/outcome_labels.py
analysis/prediction.py
analysis/relationship.py    # small support-retention extension

tests/test_prediction.py
```

---

## 12. Phase 6 Handoff

Phase 6 must not assume the Phase 5 percentages are calibrated.

Phase 6 should evaluate:

```text
walk-forward probabilities
probability calibration
three-class accuracy
Brier/log-loss or equivalent probabilistic scoring
coverage of directional predictions
cross-company robustness
cross-industry robustness
cross-timeframe robustness
cross-holding-period robustness
regime stability
out-of-sample return behavior
```

Phase 6 must still preserve the temporal boundary:

```text
train/calibrate using data strictly before prediction date
evaluate on held-out future outcome
```

The final prediction layer should not receive a hand-set universal confidence
threshold before this validation.
