TrendAnalysis Phase 5
PREDICTION ENGINE

Purpose
-------
Convert the Phase 3 current descriptive state plus Phase 4 historical
relationships into an explicit prediction object:

    Trend: UP / SIDEWAYS / DOWN / NO_CLEAR_TREND
    Conviction: STRONG / MODERATE / LOW / NONE
    Approx probabilities: UP / SIDEWAYS / DOWN

Phase 5 does NOT claim calibrated real-world probability performance.
Calibration, cross-target validation, regime robustness and trading
performance belong to Phase 6.

5.1 Outcome Classification
---------------------------
UP/SIDEWAYS/DOWN boundaries are learned from the historical forward-return
distribution for the selected holding period. No fixed return percentage is
hard-coded.

Current implementation uses empirical tertiles:
    lower boundary = 1/3 quantile
    upper boundary = 2/3 quantile

If the distribution is too small or the boundaries collapse, the prediction
is marked LIMITED rather than fabricating classes.

5.2 Method-specific prediction
------------------------------
Method A uses the exact comparable observations selected by the Phase 4
adaptive-similarity engine.

Method B uses the exact weighted historical distribution produced by the
Phase 4 adaptive-condition engine.

The Phase 4 RelationshipResult now retains raw supporting observations so
Phase 5 does not duplicate Method A/B algorithms.

5.3 Evidence-adaptive combination
----------------------------------
Method A and Method B remain separate.

They are not permanently weighted 50/50.

When both methods are usable, their probability distributions are combined
using an evidence-adaptive weight derived from their current empirical score,
reliability and effective support size.

If the two methods produce conflicting directional signals, the final trend
is NO_CLEAR_TREND rather than forcing a direction.

5.4 Direction rule
------------------
A directional prediction is allowed only when:

- UP or DOWN beats its own historical baseline share, and
- it is not overwhelmed by sampling uncertainty.

Otherwise the result is SIDEWAYS or NO_CLEAR_TREND.

5.5 Conviction rule
-------------------
STRONG:
    both methods agree directionally and both are temporally stable.

MODERATE:
    methods agree with less-than-strong stability, or only one method gives
    a usable directional signal without an opposing directional signal.

LOW:
    evidence is weak, sideways or otherwise limited.

NONE:
    no clear directional prediction is available.

These are evidence-state labels, not fixed trading thresholds.

Files
-----
analysis/outcome_labels.py
analysis/prediction.py

The Phase 4 relationship engine is included in the package with the small
support-retention extension required by Phase 5.

tests/test_prediction.py

Run
---
From the TrendAnalysis repository root:

    python -m tests.test_prediction

Integration requirement
-----------------------
The prediction engine expects a prebuilt Phase 3 current-state dictionary
and Phase 4 HistoricalRelationshipObservation history. The existing OLAP
repositories remain outside this module, preserving the architecture:

    OLAP -> Phase 2 repositories -> Phase 3 states -> Phase 4 relationships
         -> Phase 5 prediction

No raw SQL or duplicate ETL is introduced.

Important
---------
Financial publication-date uncertainty remains a Phase 3/4 limitation.
Phase 5 does not reinterpret financial ReportDate as market-availability
Date.
